package com.ait.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ait.model.SentimentScoreEntity;

public interface SentimentScoreRepository extends CrudRepository<SentimentScoreEntity, Integer> {
	List<SentimentScoreEntity>  findByUserNameOrderByTimeDesc(String username);
}
