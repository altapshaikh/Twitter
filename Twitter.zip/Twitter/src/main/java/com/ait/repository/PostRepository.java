package com.ait.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ait.model.PostEntity;

public interface PostRepository extends CrudRepository<PostEntity, Integer> {
	List<PostEntity>  findByUsernameOrderByTimeDesc(String username);
}
