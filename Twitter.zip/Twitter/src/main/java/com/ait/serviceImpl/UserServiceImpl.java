package com.ait.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ait.bean.LoginUser;
import com.ait.bean.UserBean;
import com.ait.model.UserEntity;
import com.ait.repository.UserRepository;
import com.ait.service.UserService;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
private UserRepository userRepository;
	
	
	@Override
	public UserBean registerUser(UserBean user) {
		UserEntity entity=new UserEntity();
		BeanUtils.copyProperties(user, entity);
		UserEntity userdata = userRepository.save(entity);
		BeanUtils.copyProperties(userdata, user);
		return user;
	}

	@Override
	public void deleteUser(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public UserBean updateUser(UserBean userbean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserBean fetchUserById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserBean> fetchAllUserById() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean loginUser(LoginUser user) {
		 Optional<UserEntity> byEmailAndPassword = userRepository.findByEmailAndPassword(user.getEmail(),
				user.getPassword());
		boolean present = byEmailAndPassword.isPresent();
		return present;
	}

}
