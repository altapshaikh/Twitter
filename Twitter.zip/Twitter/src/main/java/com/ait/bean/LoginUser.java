package com.ait.bean;

import lombok.Data;

@Data
public class LoginUser {
	private String email;
	private String password;
}
