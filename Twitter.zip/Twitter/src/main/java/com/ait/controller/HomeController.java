package com.ait.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.ait.bean.LoginUser;
import com.ait.bean.PostBean;
import com.ait.bean.UserBean;
import com.ait.service.UserService;

@Controller
public class HomeController {
	@Autowired
private UserService userService;
	@GetMapping
	public String getHomePage() {
		return "index";
	}

	@GetMapping(value = "/register")
	public String register(Model model) {
		model.addAttribute("user", new UserBean());
		return "registration";
	}
	  @PostMapping("/register")
	    public String processRegistration(@ModelAttribute("user") UserBean user) {
		  UserBean registerUser = userService.registerUser(user);
	        return "redirect:/login";
	    }
	
	  
	  @GetMapping("/login")
	  public String login(Model model) {
			model.addAttribute("user", new LoginUser());
			return "login";
		}
	  
	  @PostMapping("/login")
	    public String loginUser(@ModelAttribute("user") LoginUser user,Model model) {
	        boolean loginUser = userService.loginUser(user);
	        if(loginUser) {
	        	PostBean postBean = new PostBean();
	        	postBean.setUsername(user.getEmail());
	        	model.addAttribute("postcontent",postBean) ;
	        	return "homepage";
	        }else {
	        	 return "redirect:/login";
	        }
	       
	    }
}
