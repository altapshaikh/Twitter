package com.ait.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ait.bean.PostBean;
import com.ait.bean.PostWithSentimentDTO;
import com.ait.model.PostEntity;
import com.ait.service.PostService;

@Controller
public class PostController {
	@Autowired
	PostService postService;
	
	
	@PostMapping("/posttweet")
    public String loginUser(@ModelAttribute("postcontent")
    PostBean postbean,Model model) {
		ModelAndView mav=new ModelAndView();
		postbean.setTime(LocalDateTime.now());
		 List<PostEntity> post = postService.createPost(postbean);
		
    	 return "redirect:/postpage";
	}
	
	@GetMapping("/postpage")
    public ModelAndView getPostPage(Model model) {
		ModelAndView mav=new ModelAndView();
		PostBean postBean = new PostBean();
		
    	
    	mav.addObject("postcontent",postBean) ;
    	 List<PostWithSentimentDTO> post = postService.getPost("altap");
    	 post.forEach(data ->{
    		 postBean.setUsername(data.getPost().getUsername());
    		 
    	 });
    	 
    	mav.addObject("posts", post);
    	mav.setViewName("homepage");
		return mav;
	}
	
	@GetMapping("/post/delete/{id}")
    public String deletePost(@PathVariable("id") int id) {
        boolean deleted = postService.deletePostById(id);
        
	 
        return "redirect:/postpage";
    }
       
}
