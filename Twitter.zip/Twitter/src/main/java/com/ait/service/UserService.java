package com.ait.service;

import java.util.List;

import com.ait.bean.LoginUser;
import com.ait.bean.UserBean;


public interface UserService {
public  UserBean registerUser(UserBean userbean);

public boolean loginUser(LoginUser user);
public  void deleteUser(int id);
public  UserBean updateUser(UserBean userbean);
public  UserBean fetchUserById(int id);
public  List<UserBean> fetchAllUserById();
}
